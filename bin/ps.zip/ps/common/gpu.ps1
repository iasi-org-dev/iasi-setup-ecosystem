﻿. "$PSScriptRoot\gpu-selection.ps1"

function Add-IasiGpuPartition {
    param(
        [Parameter(Mandatory = $true)]
        [string]$VMName,

        [Parameter(Mandatory = $true)]
        $GPU,

        [uint32]$LowMemoryMappedIoSpace = 1GB,

        [uint64]$HighMemoryMappedIoSpace = 32GB
    )

    $VM = Get-VM -Name $VMName -ErrorAction Stop
    if ($VM.State -ne "Off") {
        throw "GPU-P can only be configured while virtual machine '$VMName' is powered off."
    }

    $Existing = @(Get-VMGpuPartitionAdapter -VMName $VMName -ErrorAction SilentlyContinue)
    if ($Existing.Count -gt 0) {
        throw "Virtual machine '$VMName' already has a GPU partition adapter."
    }

    $Selected = $GPU
    if (-not $Selected.Name -or $Selected.Kind -notin @('DiscreteCandidate','IntegratedCandidate','DisplayUnknown')) {
        throw "GPU selection did not return an eligible GPU-P device."
    }

    Write-LogInfo "Selected GPU: $($Selected.FriendlyName)"
    Write-LogInfo "GPU instance: $($Selected.Name)"

    Set-VM `
        -Name $VMName `
        -GuestControlledCacheTypes $true `
        -LowMemoryMappedIoSpace $LowMemoryMappedIoSpace `
        -HighMemoryMappedIoSpace $HighMemoryMappedIoSpace `
        -CheckpointType Disabled

    Add-VMGpuPartitionAdapter `
        -VMName $VMName `
        -InstancePath $Selected.Name | Out-Null

    $Adapter = Get-VMGpuPartitionAdapter -VMName $VMName -ErrorAction Stop
    Write-LogSuccess "GPU partition adapter assigned to '$VMName'."

    return [pscustomobject]@{
        GPU     = $Selected
        Adapter = $Adapter
    }
}


# Prepare the selected NVIDIA GPU guest resources before the seed ISO is built.
# All files are staged under this VM's own <ConfigPath>/services/gpu.
function Copy-IasiGpuGuestResources {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] $GPU,
        [Parameter(Mandatory = $true)] [string] $ConfigPath
    )

    if ($GPU.Name -notmatch '(?i)VEN_10DE') {
        throw "Linux GPU guest resource staging is currently implemented only for NVIDIA devices: $($GPU.FriendlyName)"
    }

    $SourceLib = Join-Path $env:WINDIR 'System32\lxss\lib'
    if (-not (Test-Path -LiteralPath $SourceLib -PathType Container)) {
        throw "NVIDIA WSL guest libraries not found at '$SourceLib'."
    }
    $LibraryFiles = @(Get-ChildItem -LiteralPath $SourceLib -File -Force)
    if (-not @($LibraryFiles | Where-Object { $_.Name -like 'libcuda.so*' }).Count) {
        throw "No libcuda.so files found in '$SourceLib'."
    }

    $ServicesPath = Join-Path $ConfigPath 'services'
    if (-not (Test-Path -LiteralPath $ServicesPath -PathType Container)) {
        throw "Services directory not found: '$ServicesPath'."
    }
    $GpuPath = Join-Path $ServicesPath 'gpu'
    $LibTarget = Join-Path $GpuPath 'lib'
    $DriverTarget = Join-Path $GpuPath 'drivers'

    # Never retain old libraries from a previous host driver version.
    if (Test-Path -LiteralPath $GpuPath) {
        Remove-Item -LiteralPath $GpuPath -Recurse -Force -ErrorAction Stop
    }
    New-Item -ItemType Directory -Path $LibTarget -Force | Out-Null
    New-Item -ItemType Directory -Path $DriverTarget -Force | Out-Null

    Write-LogInfo "Staging NVIDIA guest libraries for $($GPU.FriendlyName)..."
    Copy-Item -Path (Join-Path $SourceLib '*') -Destination $LibTarget -Recurse -Force -ErrorAction Stop
    Write-LogSuccess "NVIDIA libraries copied to '$LibTarget' ($($LibraryFiles.Count) top-level files)."

    # Resolve the selected GPU's exact PnP driver package. Never take the
    # first arbitrary NVIDIA directory from FileRepository.
    if (-not $GPU.PnpId) {
        throw "Selected GPU has no resolved PnP ID: $($GPU.FriendlyName)"
    }
    Write-LogInfo "Resolving installed driver package for $($GPU.PnpId)..."
    $Signed = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop |
        Where-Object { $_.DeviceID -ieq $GPU.PnpId -and $_.InfName })
    if ($Signed.Count -ne 1) {
        throw "Expected one signed PnP driver for '$($GPU.PnpId)', found $($Signed.Count)."
    }
    $InfName = [string]$Signed[0].InfName
    Write-LogInfo "Installed INF: $InfName; driver version: $($Signed[0].DriverVersion)"

    # DISM maps the published oem*.inf to the original INF in DriverStore.
    $Packages = @(Get-WindowsDriver -Online -All -ErrorAction Stop |
        Where-Object { $_.Driver -ieq $InfName })
    if ($Packages.Count -ne 1) {
        throw "Could not uniquely resolve INF '$InfName' in the online DriverStore (matches: $($Packages.Count))."
    }
    $OriginalInf = [string]$Packages[0].OriginalFileName
    if ([string]::IsNullOrWhiteSpace($OriginalInf) -or -not (Test-Path -LiteralPath $OriginalInf -PathType Leaf)) {
        throw "DriverStore original INF is missing: '$OriginalInf'."
    }
    $PackagePath = Split-Path -Parent $OriginalInf
    $DriverStoreRoot = [IO.Path]::GetFullPath((Join-Path $env:WINDIR 'System32\DriverStore\FileRepository'))
    $CanonicalPackagePath = [IO.Path]::GetFullPath($PackagePath)
    if (-not $CanonicalPackagePath.StartsWith($DriverStoreRoot.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw "Resolved driver directory is outside FileRepository: '$CanonicalPackagePath'."
    }

    Write-LogInfo "Copying selected GPU driver package contents: $CanonicalPackagePath"
    $Items = @(Get-ChildItem -LiteralPath $CanonicalPackagePath -Force -ErrorAction Stop)
    if ($Items.Count -eq 0) {
        throw "Selected DriverStore package is empty: '$CanonicalPackagePath'."
    }
    foreach ($Item in $Items) {
        Copy-Item -LiteralPath $Item.FullName -Destination $DriverTarget -Recurse -Force -ErrorAction Stop
    }
    $CopiedInf = Join-Path $DriverTarget (Split-Path $OriginalInf -Leaf)
    if (-not (Test-Path -LiteralPath $CopiedInf -PathType Leaf)) {
        throw "Copied driver package verification failed: '$CopiedInf'."
    }

    # Preserve original Windows DriverStore identity for auditability.
    $TracePath = Join-Path $DriverTarget 'driverstore-source.txt'
    @(
        "DriverStoreFolder: $(Split-Path $CanonicalPackagePath -Leaf)"
        "DriverStorePath: $CanonicalPackagePath"
        "PublishedINF: $InfName"
        "OriginalINF: $(Split-Path $OriginalInf -Leaf)"
        "DriverVersion: $($Signed[0].DriverVersion)"
        "GPU: $($GPU.FriendlyName)"
        "PnPDeviceID: $($GPU.PnpId)"
    ) | Set-Content -LiteralPath $TracePath -Encoding UTF8 -ErrorAction Stop
    Write-LogSuccess "GPU driver package contents staged in '$DriverTarget'."
    Write-LogInfo "DriverStore trace saved to '$TracePath'."
    Write-LogInfo 'NVIDIA guest resources are ready for recursive seed ISO inclusion.'
}
